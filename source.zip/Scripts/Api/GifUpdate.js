const InputSearch = document.querySelector(".Search");
function httpGetAsync(theUrl, callback)
{
    // create the request object
    var xmlHttp = new XMLHttpRequest();

    // set the state change callback to capture when the response comes in
    xmlHttp.onreadystatechange = function()
    {
        if (xmlHttp.readyState == 4 && xmlHttp.status == 200)
        {
            callback(xmlHttp.responseText);
        }
    }

    // open as a GET call, pass in the url and set async = True
    xmlHttp.open("GET", theUrl, true);

    // call send with no params as they were passed in on the url string
    xmlHttp.send(null);

    return;
}

// callback for the top 8 GIFs of search
function tenorCallback_search(responsetext)
{
    var response_objects = JSON.parse(responsetext);

    let gifs = response_objects["results"];
    // load the GIFs -- for our example we will load the first GIFs preview size (nanogif) and share size (gif)
    if(document.getElementById("stickers").checked == false){
    	Main.src=gifs[0]["media_formats"]["gif"]["url"];
    }else{
    	Main.src=gifs[0]["media_formats"]["gif_transparent"]["url"];
    }
    return;
}
export function nextImage()
{
    // set the apikey and limit
    var apikey = "AIzaSyBPCEe-KyjlWdroCAE0fFvS5Yxbrk6YhJ0";
    var clientkey = "RandomImage";

    if(InputSearch.value == ""){
    	var search_term = "hello anime";
    }
    else {
    	var search_term = InputSearch.value;
    }

    // using default locale of en_US
    if(document.getElementById("stickers").checked == false){
    var search_url = "https://tenor.googleapis.com/v2/search?q=" + search_term + "&locale=ru_RU" +  "&key=" + apikey
    +"&client_key=" + clientkey + "&random=true";
    }
	else{
    	var search_url = "https://tenor.googleapis.com/v2/search?q=" + search_term + "&locale=ru_RU" +  "&key=" + apikey
    	+"&client_key=" + clientkey + "&random=true"+"&searchfilter=sticker";
    }
    httpGetAsync(search_url,tenorCallback_search);
    return;
}
nextImage();