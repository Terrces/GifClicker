import {Alert} from "./WindowLogics/WindowLogic.js";
let PatchNotesFetch = await fetch("https://raw.githubusercontent.com/Terrces/GifClicker/main/PatchNotes.json");
let PatchNotes = await PatchNotesFetch.json();

const Version = "0.4.6";

if (PatchNotes.UpdateNumbers[PatchNotes.UpdateNumbers.length-1] != Version){
	Alert("Ошибка обновления! Нажмите Ctrl+f5 для перезагрузки страницы","Обновление может придти в течении 5 минут",900000000)
	// alert("Ошибка обновления! Нажмите Ctrl+f5 для перезагрузки страницы");
}