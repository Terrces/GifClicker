//поля ввода
export const InputSearch = document.querySelector(".Search");
//кнопки
export const ToggleGifBlockButton = document.querySelector(".ChangeGifBlockButton");
export const ToggleUpgradesBlockButton = document.querySelector(".UpgradesBlockButton");
//текст
export const countText = document.querySelector(".count");
export const tmoney = document.querySelector(".money");
//окна
export const CollectionWindow = document.querySelector(".Collection");
export const SettingsWindow = document.querySelector(".SettingsWindow");
export const shopWindow = document.querySelector(".shopWindow");
export const MainWindow = document.querySelector(".MainWindow");
export const alarmWindow = document.querySelector(".alarm");