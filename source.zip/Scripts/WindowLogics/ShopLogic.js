import * as Variables from '../Variables.js';
import {priceUpgrades, upgrade} from '../script.js';
function ToggleGroupe(Block,CurrentButton){
	if(Block.style.opacity != "0"){
		CurrentButton.textContent = "Открыть группу";
		Block.style.cssText = "position:absolute; opacity:0; pointer-events:none;top:0px;";
	}else{
		CurrentButton.textContent = "Закрыть группу";
		Block.style.cssText = "position:static; opacity:100;pointer-events:auto; transition:1s ease;";
	}
}
//Закрытие всех групп в магазине:
function HideAllGroups(){
	document.querySelector(".UpgradesBlock").style.cssText = "position:absolute; opacity:0; pointer-events:none;top:0px;";
	document.querySelector(".ChangeGifBlock").style.cssText = "position:absolute; opacity:0; pointer-events:none;top:0px;";
	Variables.ToggleGifBlockButton.textContent = "Открыть группу";
	Variables.ToggleUpgradesBlockButton.textContent = "Открыть группу";
}

let AutoUpgrade = document.getElementById("autoUpgrade")

AutoUpgrade.addEventListener("click",function(){
	if(AutoUpgrade.checked == true){
		setInterval(() => {
			upgrade(1,0.16,0.15);
		},1);
	}
})

CloseAllGroupesButton.addEventListener("click",function(){HideAllGroups()})
//переключение группы "Change Gif" в магазине:
Variables.ToggleGifBlockButton.addEventListener("click",function(){ToggleGroupe(document.querySelector(".ChangeGifBlock"),Variables.ToggleGifBlockButton);})
//переключение группы "Updates" в магазине:
Variables.ToggleUpgradesBlockButton.addEventListener("click",function(){ToggleGroupe(document.querySelector(".UpgradesBlock"),Variables.ToggleUpgradesBlockButton);})
HideAllGroups();