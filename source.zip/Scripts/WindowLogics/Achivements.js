// OpenAchievementsButton.onclick = function(){
//     achievements.style.display = "flex";
//     if(achievements.style.display == "flex"){
//         let achievement = document.createElement("div");
//         let achievementText = document.createElement("text");
//         achievementText.textContent = "test";
//         AllAchievementsContainer.append(achievementText);
//     }
// }
// if(achievements.style.display != "flex"){
//     document.getElementById("achievements").removeChild();
// }