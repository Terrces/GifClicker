function noselect(){return false;} function select(){return true;} document.ondragstart = noselect; document.onselectstart = noselect;
import {CollectionWindow,shopWindow,SettingsWindow} from '../Variables.js';
import {GifsInLibraryCreate,DeleteById} from './CollectionLogic.js';

//кнопки для открытия окон
const CloseWindow = document.querySelectorAll("#CloseWindowbutton");

function OpenWindow(WindowName){ WindowName.style.display = "block"}
CollectionOpen.onclick=function(){
	GifsInLibraryCreate();
	OpenWindow(CollectionWindow);
}
OpenSettingsButton.onclick=function(){OpenWindow(SettingsWindow);}
OpenShopWindow.onclick=function(){OpenWindow(shopWindow);}

export function AutoCloseWindows(){
	if(CollectionWindow.style.display != "none"){DeleteById("DeleteThis");}
	CollectionWindow.style.display = "none";
	shopWindow.style.display = "none";
	SettingsWindow.style.display = "none";
	achievements.style.display = "none";
}


CloseWindow.forEach(button => {
	button.addEventListener("click",(event)=>
	{
		AutoCloseWindows();
	});
});

export function Alert(Messege,description,time){
	const alertwindow = document.createElement("form");
	const text = document.createElement("text");
	const descriptiontext = document.createElement("text");
	alertwindow.id = "Alert";
	text.textContent = Messege;
	text.style.fontSize = "larger";
	descriptiontext.textContent = description;
	descriptiontext.style.color = "#9dff7d";
	descriptiontext.style.fontSize = "large";
	descriptiontext.style.marginTop = "1em";
	alertwindow.append(text,descriptiontext);
	document.querySelector("body").append(alertwindow);
	setTimeout(() => {alertwindow.style.opacity = 100;},0);
	setTimeout(() => {alertwindow.style.opacity = 0;},time-300);
	setTimeout(() => {alertwindow.remove();},time);
}