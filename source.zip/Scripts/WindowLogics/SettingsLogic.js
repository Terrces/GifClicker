// import changelog from '../../Data/ChangeLog.json' with {type: 'json'}
//https://raw.githubusercontent.com/Terrces/ChangeLogs/main/GameInfo.json
let PatchNotesFetch = await fetch("https://raw.githubusercontent.com/Terrces/GifClicker/main/PatchNotes.json");
let PatchNotes = await PatchNotesFetch.json()

const body = document.querySelector("body");
const button = document.querySelectorAll(".buttonimg");
const ShopProduct = document.querySelectorAll(".ProductBlock");
export function ThemeApply(){
	const darkness = document.getElementById("darkness");
	if(darkness.value >=100) {
		button.forEach(btn => {
			btn.style.filter = "invert(0)";
		})
		ShopProduct.forEach(a => {
			a.style.color = "black";
			a.style.backgroundColor = "rgba(255,255,255,0.6);";
			
		})
		body.style.color = "black";
	}
	else {
		button.forEach(btn => {
			btn.style.filter = "invert(1)";
		})
		ShopProduct.forEach(a => {
			a.style.color = "white";
			a.style.backgroundColor = "rgba(0,0,0,0.2);";
		})
		body.style.color = "white";
	}
	body.style.backgroundColor = "rgb("+darkness.value+","+darkness.value+","+darkness.value+")";
}

document.getElementById("darkness").onchange = function(){
	ThemeApply();
}
ThemeApply();
for(let i = 0; i < PatchNotes.UpdateNumbers.length;i++){
	document.getElementById("CurrentVersion").textContent = "Версия: "+PatchNotes.UpdateNumbers[i];
	document.getElementById("CurrentVersionName").textContent = PatchNotes.PatchNotesNames[i];
}
