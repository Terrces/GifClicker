// import GameInfo from "../Data/GameInfo.json" with{type: 'json'}

import * as animation from "./Animation.js";
import {nextImage} from './Api/GifUpdate.js';
import * as Variables from './Variables.js';
import {Alert} from "./WindowLogics/WindowLogic.js";
let GameInfoFetch = await fetch("https://raw.githubusercontent.com/Terrces/GifClicker/main/GameInfo.json");
let GameInfo = await GameInfoFetch.json();

export let GifCoin = 0;
export let GifLibrary = [];
export let StatsCountUpgrades=[0,0,0];
export let priceUpgrades = [1,5];
export let priceAnother = [2,10];
export let multiply = [1,0];

document.getElementById("stickers").onclick=function(){GifRefresh();};

export function upgrade (id,addmultiply,addprice) {
	if(GifCoin >= priceUpgrades[id]){
		animation.substractAnimation(id,"Upgrades");
		StatsCountUpgrades[id] += 1;
		GifCoin -= priceUpgrades[id];
		multiply[id] += addmultiply;
		priceUpgrades[id] += addprice+multiply[id];
		localStorage.setItem('UpgradesPrice',JSON.stringify(priceUpgrades));
		localStorage.setItem('Upgrades',JSON.stringify(multiply));
		textcountupdate();
	}
}

export function GifRefresh(){
	if(GifCoin >= priceAnother[0]){
		animation.substractAnimation(0,"UpgradeAnother");
		GifCoin -= priceAnother[0];
		priceAnother[0] += 3;
		nextImage();
		textcountupdate();
	}
}
function AppendGifInCollection(){
	let avalible = false;
	if(GifLibrary.length == 0)
		avalible = true;
	for(let i = 0;i < GifLibrary.length;i++){
		GifLibrary[i];
		if(GifLibrary[i] != document.getElementById("Main").src)
			avalible = true;
		else
			avalible = false
	}
	if(avalible == false){
		Alert("Вы уже добавили данную гифку","",1500)
	}

	if(avalible == true && priceAnother[1] <= GifCoin){
		// animation.GifAppendCollection();
		animation.substractAnimation(1,"UpgradeAnother");
		GifCoin -= priceAnother[1];
		priceAnother[1] += 5;
		GifLibrary.push(document.getElementById("Main").src);
		localStorage.setItem('GifCollection',JSON.stringify(GifLibrary));
		textcountupdate();
		avalible = false
	}
}
clicker.addEventListener("click", function (){
	animation.AddAnimation(0,"Clicker")
	GifCoin += multiply[0];
	textcountupdate();
})

document.getElementById("AppendInCollection").onclick = function(){AppendGifInCollection();}
BuyGifRefresh.onclick = function() {GifRefresh();}
BuyGifRefresh1.onclick = function() {GifRefresh();}
Variables.InputSearch.onchange = function(){GifRefresh();}
upgradeClicks.onclick = function(){upgrade(0,0.05,0.25);}
UpgradeAutoClicks.onclick = function(){upgrade(1,0.16,0.15);}

async function textcountupdate (){
	let gifcoinsNames = ["GifCoin"," GifCoin'ов"];
	localStorage.setItem('coins',GifCoin);
	
	GifRefresh1.textContent = GifRefresh.textContent = "Стоимость:" + Math.ceil(priceAnother[0]) + gifcoinsNames[1];
	autoClicksPrice.textContent ="Стоимость: "+ priceUpgrades[1].toFixed(1) + gifcoinsNames[1];
	clicks.textContent =" Стоимость: "+ priceUpgrades[0].toFixed(1) + gifcoinsNames[1];
	Variables.tmoney.textContent = gifcoinsNames[1]+ ": " + GifCoin.toFixed(1);

	AddInCollection.textContent = " Стоимость: "+ priceAnother[1].toFixed(1) + gifcoinsNames[1];
	MultiplyAutoClicks.textContent = "Прибавляет: "+ multiply[1].toFixed(2) +" Gifcoin'ов в секунду";
	Variables.countText.textContent =  gifcoinsNames[1]+ ": "+ GifCoin.toFixed(1);
	
	document.title = GameInfo.Name + "Монет: " + GifCoin.toFixed(1);
	
}
textcountupdate();

export default GifLibrary;
setInterval(function(){
	animation.AddAnimation(1,"AllUpgrades");
	GifCoin += multiply[1];textcountupdate();
},1000);