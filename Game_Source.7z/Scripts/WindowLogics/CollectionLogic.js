import GifLibrary from "../script.js";
import {ThemeApply} from "./SettingsLogic.js";
export function GifsInLibraryCreate(){
	for(let i=0;i < GifLibrary.length;i++){

		const librarybase = document.querySelector(".allgifs");
		const CreateBlock= document.createElement('div');
		const CreateGif= document.createElement('img');
		const giflink = document.createElement('text');
		const choisebutton = document.createElement('button');
		const removebutton = document.createElement('button');
		const CopyLinkbutton = document.createElement('button');
		const deleteIcon = document.createElement("img");
		deleteIcon.className = "buttonimg";
		deleteIcon.src = "../../Pictures/Icons/delete.svg";
		CreateBlock.className = "CollectionGif";
		CreateBlock.id = "DeleteThis";
		choisebutton.textContent = "Choise";
		removebutton.textContent = "Delete";
		ThemeApply();
		CopyLinkbutton.textContent = "Copy GIF";
		choisebutton.onclick = function(){Main.src = GifLibrary[choisebutton.id]}
		removebutton.onclick = function()
		{
			DeleteById("DeleteThis");
			//console.log(GifLibrary);
			GifLibrary.splice(removebutton.id,1);
			localStorage.setItem('GifCollection',JSON.stringify(GifLibrary));
			GifsInLibraryCreate();
		}
		choisebutton.className = "ChoiseThisGif";
		removebutton.className = "DeleteThisGif";

		librarybase.prepend(CreateBlock);
		CreateBlock.append(CreateGif,CopyLinkbutton,choisebutton,removebutton);

		CreateGif.src = giflink.textContent=GifLibrary[i];
		CopyLinkbutton.id = removebutton.id = choisebutton.id = CreateGif.id = i;
		ThemeApply();
	}
}
export function DeleteById(id){
	for(let i=0;i < GifLibrary.length;i++){
		document.getElementById(id).remove();
}}