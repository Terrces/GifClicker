let PatchNotesFetch = await fetch("https://raw.githubusercontent.com/Terrces/GifClicker/main/PatchNotes.json");
let PatchNotes = await PatchNotesFetch.json()

const body = document.querySelector("body");
let button = document.querySelectorAll(".buttonimg");
const ShopProduct = document.querySelectorAll(".ProductBlock");
const darkness = document.getElementById("darkness");

export function ThemeApply(){
	let theme = localStorage.getItem("Theme");
	if(localStorage.getItem("Theme") != null){
		if(theme >=100) {
			button.forEach(btn => {
				btn.style.filter = "invert(0)";
			})
			ShopProduct.forEach(a => {
				a.style.color = "black";
				a.style.backgroundColor = "rgba(255,255,255,0.6);";
			})
			body.style.color = "black";
		}
		else {
			button.forEach(btn => {
				btn.style.filter = "invert(1)";
			})
			ShopProduct.forEach(a => {
				a.style.color = "white";
				a.style.backgroundColor = "rgba(0,0,0,0.2);";
			})
			body.style.color = "white";
		}
	
		body.style.backgroundColor = "rgb("+theme+","+theme+","+theme+")";
	}
}
document.getElementById("darkness").onchange = function(){
	if(localStorage.getItem("Theme") != darkness.value){
		localStorage.setItem("Theme",darkness.value);
		ThemeApply();
	}
}
ThemeApply();
darkness.value = localStorage.getItem("Theme");
for(let i = 0; i < PatchNotes.UpdateNumbers.length;i++){
	document.getElementById("CurrentVersion").textContent = "Версия: "+ PatchNotes.UpdateNumbers[i];
	document.getElementById("CurrentVersionName").textContent = PatchNotes.PatchNotesNames[i];
}
